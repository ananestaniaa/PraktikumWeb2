<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use App\Models\BukuModel;

class Buku extends Seeder
{
    public function run()
    {
        $this->db->table('buku')->insert([
            'judul' => 'Ceros dan Batozar',
            'penulis' => 'Tere Liye',
            'penerbit' => 'Gramedia',
            'tahun_terbit' => '2018'
        ]);

        $this->db->table('buku')->insert([
            'judul' => 'Komet Minor',
            'penulis' => 'Tere Liye',
            'penerbit' => 'Gramedia',
            'tahun_terbit' => '2019'
        ]);

        $this->db->table('buku')->insert([
            'judul' => 'Nebula',
            'penulis' => 'Tere Liye',
            'penerbit' => 'Gramedia',
            'tahun_terbit' => '2020'
        ]);
    }
}
