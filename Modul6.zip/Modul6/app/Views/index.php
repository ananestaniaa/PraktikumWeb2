<!DOCTYPE html>
<html>
<head>
    <title>Beranda</title>
    <style>
    * {
        box-sizing: border-box;
    }
    body {
    font-family: 'Poppins', sans-serif;
    background-color: #feecef;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    background-color: #ffcce5;
    border-radius: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    margin-top: 100px;
    transform-style: preserve-3d;
}

h1 {
    color: #DC055E;
    text-align: center;
    margin-bottom: 20px;
}

table {
    width: 100%;
    margin-left: auto;
    margin-right: auto;
    border-radius: 10px;
}

th,
td {
    padding: 10px;
    text-align: left;
}

th {
    width: 30%;
}

tr:nth-child(odd) {
background-color: #ffeff1;
}

tr:nth-child(even) {
background-color: #ffcce5;
}

.btn-container {
display: flex;
justify-content: center;
}

.btn-container {
    display: flex;
    justify-content: center;
}

button {
    margin-top: 10px;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    background-color: #F5077D;
    color: #fff;
    font-family: 'Poppins', sans-serif;
    font-size: 16px;
    font-weight: bold;
    text-transform: uppercase;
    cursor: pointer;
    transition: background-color 0.3s ease;
    position: relative;
    overflow: hidden;
}

button:hover {
    background-color: #DC055E;
}
</style>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">

</head>
<body>
    <div class="container">
        <h1>Hi! I'm Ana</h1>
        <table>
            <tr>
                <td colspan="2" style="text-align: center;">
                    <strong>Nama</strong>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align: center;">
                    <?= $nama ?>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align: center;">
                    <strong>NIM</strong>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align: center;">
                    <?= $nim ?>
                </td>
            </tr>
        </table>
        <div class="btn-container">
            <form action="/home/biodata">
                <button>
                    Profil
                </button>
            </form>
        </div>
    </div>
</body>
</html>