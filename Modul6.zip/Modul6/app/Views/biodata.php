<!DOCTYPE html>
<html>

<head>
    <title>Profil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
    body, h1, th, td, button {
            font-family: 'Poppins', sans-serif;
        }
    body {
        background-color: #feecef;
        padding: 20px;
        color: #ffffff;
    }

    .container {
        max-width: 450px; /* Mengubah lebar maksimum container */
        margin: 0 auto;
        background-color: #F8A5C2;
        border-radius: 10px;
        padding: 30px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
    }

    h1 {
        text-align: center;
        margin-bottom: 30px;
        font-weight: bold;
        color: #DC055E;
    }

    table {
        width: 100%;
        background-color: #F6CEE3;
        color: #000000;
        border-radius: 10px;
    }

    th,
    td {
        padding: 10px;
        text-align: left;
    }

    th:not(:last-child),
    td:not(:last-child) {
        border-right: 1px solid #F6CEE3;
    }

    th {
        width: 30%;
    }

    .profile-img {
        width: 170px;
        height: 170px;
        border-radius: 50%;
        object-fit: cover;
        object-position: center;
        margin: 0 auto;
    }

    .btn-container {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }

    .btn-container button {
        font-family: 'Poppins', sans-serif;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        background-color: #F5077D;
        color: #ffffff;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .btn-container button:hover {
        background-color: #DC055E;
    }
    </style>
</head>

<body>
    <div class="container">
        <h1>About Me</h1>

        <table>
            <tr style="background-color: #F6CEE3;">
                <td colspan="3" style="text-align: center;">
                    <img src="<?= base_url('images/' . $foto) ?>" class="profile-img">
                </td>
            </tr>
            <tr style="background-color: #F8A5C2;">
                <th>Nama Lengkap</th>
                <td colspan="2">
                    <?= $nama; ?>
                </td>
            </tr>
            <tr>
                <th>NIM</th>
                <td colspan="2">
                    <?= $nim; ?>
                </td>
            </tr>
            <tr style="background-color: #F8A5C2;">
                <th>Asal Prodi</th>
                <td colspan="2">
                    <?= $prodi; ?>
                </td>
            </tr>
            <tr>
                <th>Hobi</th>
                <td colspan="2">
                    <?= $hobi; ?>
                </td>
            </tr>
            <tr style="background-color: #F8A5C2;">
                <th>Skill</th>
                <td colspan="2">
                    <?= $skill; ?>
                </td>
            </tr>
            <tr>
                <th>Cita - Cita</th>
                <td colspan="2">
                    <?= $citacita; ?>
                </td>
            </tr>
        </table>
    </div>
    <div class="btn-container">
        <form action="/home/index">
            <button>Beranda</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
