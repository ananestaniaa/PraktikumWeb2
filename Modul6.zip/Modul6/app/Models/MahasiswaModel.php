<?php

namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel extends Model
{
    protected $nama = "Ana Nestania";
    protected $nim = "2110817220011";
    protected $prodi = "Teknologi Informasi";
    protected $cita_cita = "UI/UX Designer";
    protected $hobi = "Nonton";
    protected $skill = "Desain";
    protected $foto = "foto.png";

    public function getNama()
    {
        return $this->nama;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function getcita_cita()
    {
        return $this->cita_cita;
    }
    public function gethobi()
    {
        return $this->hobi;
    }
    public function getSkill()
    {
        return $this->skill;
    }
    public function getFoto()
    {
        return $this->foto;
    }
}